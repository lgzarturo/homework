# Items stuff

Directorio con el listado de artículos.

menu.json
{
  "item1": {"name":"Coca Cola","description":"Botella 1.5 lt","price":17.00},
  "item2": {"name":"Sabritas","description":"Bolsa 350 gr","price":16.00},
  "item3": {"name":"Carlos V","description":"Chocolate 20 gr","price":6.00}
}
